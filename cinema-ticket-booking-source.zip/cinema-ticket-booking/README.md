# Cinema Ticket Booking

An Express and EJS web application for movie listings, screenings, bookings, ticket management, and an admin dashboard. Mongoose connects the application to MongoDB.

## Run locally

1. Install Node.js and run `npm ci` from this folder.
2. Start a local MongoDB instance. Copy `.env.example` to `.env` and set a new `JWT_SECRET` for your local instance.
3. Run `npm start` and open [the local app](http://localhost:3000).
4. Add demo movie records and images you can use. Movie artwork goes under `public/uploads/`.

## Source map

- `server.js` starts the Express app.
- `controllers/` and `routes/` contain the application logic.
- `views/` contains EJS templates.
- `public/` contains browser-side code and styles.
